export enum Role {
    Servicios = 'Servicios',
    Operador = 'Operador',
    Reportes = 'Reportes',
    Administrador = 'Administrador',
    Tablero = 'Tablero',
  }