export class User {
    usuario: string;
    correo: string;
    token: string;
    url_imagen: string;
    roles: string[];
    cod_compania: string[];
}