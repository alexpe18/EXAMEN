import { Component } from '@angular/core';

@Component({
  selector: 'app-banners',
  templateUrl: './banners.component.html'
})
export class AppBannersComponent {

  constructor() { }

}
