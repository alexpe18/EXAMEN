import { Component } from '@angular/core';
import{AppFormComponent} from 'src/app/components';

@Component({
  selector: 'app-servicio',
  imports: [AppFormComponent],
  standalone: true,
  templateUrl: './servicio.component.html',
})
export class AppServicioComponent {
  constructor(){}
 }
