import { Component } from '@angular/core';

@Component({
  selector: 'app-account-setting',
  templateUrl: './account-setting.component.html',
})
export class AppAccountSettingComponent {
  constructor() {}
}
