import { Component } from '@angular/core';
@Component({
  selector: 'app-faq',
  templateUrl: './faq.component.html',
})
export class AppFaqComponent {
  constructor() {}

  // 1 basic
  panelOpenState = false;
}
