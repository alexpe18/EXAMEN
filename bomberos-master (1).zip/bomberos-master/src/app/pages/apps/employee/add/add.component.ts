import { Component } from '@angular/core';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
})
export class AppAddEmployeeComponent {
  constructor() { }
}
