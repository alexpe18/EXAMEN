import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-email',
  templateUrl: './email.component.html'

})
export class AppEmailComponent {
  constructor() { }
}
