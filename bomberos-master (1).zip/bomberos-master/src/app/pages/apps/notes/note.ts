export interface Note {
  color: string;
  title: string;
  datef: Date;
}
