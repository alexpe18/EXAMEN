import { Component } from '@angular/core';

@Component({
  selector: 'app-ok-dialog',
  templateUrl: './ok-dialog.component.html'
})
export class OkDialogComponent {
  constructor() { }
}
