import { Component } from '@angular/core';

@Component({
  selector: 'app-added-dialog',
  templateUrl: './added-dialog.component.html'
})
export class AddedDialogComponent {
  constructor() { }
}
