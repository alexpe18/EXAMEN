export const messages = [
    {
      from: 'James Johnson',
      photo: 'assets/images/profile/user-1.jpg',
      subject: 'Hey, how are you?',
      chat: [
        {
          type: 'odd',
          msg: 'Hi Luke.',
          date: new Date('2016-01-05'),
        },
        {
          type: 'odd',
          msg: 'How are you my friend?',
          date: new Date('2016-01-06'),
        },
        {
          type: 'even',
          msg: 'I am good and what about you?',
          date: new Date('2016-01-07'),
        },
        {
          type: 'odd',
          msg: 'Lorem Ipsum is simply dummy text of the printing & type setting industry.',
          date: new Date('2016-01-08'),
        },
        {
          type: 'even',
          msg: 'I would love to join the team.',
          date: new Date('2016-01-09'),
        },
        {
          type: 'odd',
          msg: 'Well we have good budget for the project.',
          date: new Date('2016-01-10'),
        },
      ],
    },
    {
      from: 'Maria Hernandez',
      photo: 'assets/images/profile/user-2.jpg',
      subject: 'Lorem ipsum done dkaghdka',
      chat: [
        {
          type: 'odd',
          msg: 'this is odd2',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even2',
          date: new Date('2016-01-10'),
        },
        {
          type: 'odd',
          msg: 'Simply dummy text of the printing & type setting industry.',
          date: new Date('2016-01-08'),
        },
        {
          type: 'even',
          msg: 'Love to join the team.',
          date: new Date('2016-01-09'),
        },
        {
          type: 'odd',
          msg: 'Have good budget for the project.',
          date: new Date('2016-01-10'),
        },
      ],
    },
    {
      from: 'David Smith',
      photo: 'assets/images/profile/user-3.jpg',
      subject: 'Thanks mate',
      chat: [
        {
          type: 'odd',
          msg: 'Hi Luke.',
          date: new Date('2016-01-05'),
        },
        {
          type: 'odd',
          msg: 'How are you my friend?',
          date: new Date('2016-01-06'),
        },
        {
          type: 'even',
          msg: 'I am good and what about you?',
          date: new Date('2016-01-07'),
        },
        {
          type: 'odd',
          msg: 'Lorem Ipsum is simply dummy text of the printing & type setting industry.',
          date: new Date('2016-01-08'),
        },
        {
          type: 'even',
          msg: 'I would love to join the team.',
          date: new Date('2016-01-09'),
        },
        {
          type: 'odd',
          msg: 'Well we have good budget for the project.',
          date: new Date('2016-01-10'),
        },
      ],
    },
    {
      from: 'Maria Rodriguez',
      photo: 'assets/images/profile/user-4.jpg',
      subject: 'This is my shot',
      chat: [
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
      ],
    },
    {
      from: 'Robert Smith',
      photo: 'assets/images/profile/user-5.jpg',
      subject: 'You have to do it with your self',
      chat: [
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
      ],
    },
    {
      from: 'Joseph Sarah',
      photo: 'assets/images/profile/user-6.jpg',
      subject: 'No mate this is not',
      chat: [
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
      ],
    },
    {
      from: 'Thomas Smith',
      photo: 'assets/images/profile/user-1.jpg',
      subject: 'Arti thai gai ne?',
      chat: [
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
        {
          type: 'odd',
          msg: 'this is odd',
          date: new Date('2016-01-10'),
        },
        {
          type: 'even',
          msg: 'this is even',
          date: new Date('2016-01-10'),
        },
      ],
    },
  ];
  