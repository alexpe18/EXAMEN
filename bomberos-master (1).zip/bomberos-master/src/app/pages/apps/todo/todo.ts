export class ToDo {
  id = 0;
  public message = '';
  public completionStatus = false;
  public edit = false;
  public date: Date | null = null;
}
