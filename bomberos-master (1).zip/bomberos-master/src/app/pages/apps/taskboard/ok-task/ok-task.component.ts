import { Component } from '@angular/core';

@Component({
  selector: 'app-ok-task',
  templateUrl: './ok-task.component.html',
})
export class OkAppTaskComponent {
  constructor() {}
}
