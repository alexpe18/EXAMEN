import { Component } from '@angular/core';

@Component({
  selector: 'app-delete-task',
  templateUrl: './delete-task.component.html',
})
export class DeleteAppTaskComponent {
  constructor() {}
}
